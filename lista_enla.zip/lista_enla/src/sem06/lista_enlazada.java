/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sem06;

/**
 *
 * @author o12310
 */
public class lista_enlazada {

    private nodo head; // Referencia al primer nodo (cabeza)
    private int size; // Número de elementos en la lista
// Constructor: crea una lista vacía

    public lista_enlazada() {
        this.head = null; // La lista empieza vacía
        this.size = 0; // Tamaño inicial es cero
    }

    public void insertarAlInicio(int clave) {
        nodo temp = new nodo(clave); // Crea nuevo nodo
        temp.siguiente = head; // Apunta nuevo nodo al inicio actual
        head = temp; // Actualiza la cabeza de la lista
        size++;
    }
    public void add_tail(int key){
        nodo tail = new nodo(key);
        if (head==null) {
            head=tail;
        }
        else{
            nodo temp =head;
            while (temp.siguiente !=null)                
                temp=temp.siguiente;
            
            temp.siguiente=tail;
        }
        tail.siguiente=null;
        size++;
    }
    public nodo getHead(){
        return head;
    }
}
