/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sem06;

/**
 *
 * @author o12310
 */
public class projecto {
    public static void main(String[] args) {
        lista_enlazada L= new lista_enlazada();
        L.insertarAlInicio(7);
        L.add_tail(2);
        L.add_tail(3);
        L.add_tail(6);
        nodo temp = L.getHead();
        while (temp.siguiente!=null) {            
            System.out.println(temp.clave);
            temp=temp.siguiente;
        }
        System.out.println("");
    }
}
