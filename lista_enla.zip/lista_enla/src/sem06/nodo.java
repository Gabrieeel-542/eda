package sem06;

public class nodo {

    int clave; // Dato almacenado
    nodo siguiente; // Referencia al siguiente nodo
// Constructor

    public nodo(int clave) {
        this.clave = clave;
        this.siguiente = null;
    }
}
